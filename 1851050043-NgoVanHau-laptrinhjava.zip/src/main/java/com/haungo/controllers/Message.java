package com.haungo.controllers;

public class Message {
}
