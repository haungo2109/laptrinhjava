package com.haungo.pojos;

/**
 * @author kan_haungo
 */
public enum StatusAuction {
    success, inprocess, fail, being
}
