package com.haungo.pojos;

public enum StatusTransaction {
    none, inprocess, fail, success
}
